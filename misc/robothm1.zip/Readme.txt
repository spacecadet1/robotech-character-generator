Robotech Theme
--------------

Author: Frederic Oriol (Cookie Monster)
E-mail: goriol@po-box.mcgill.ca
Version: 1.0
Date: July 31st, 1996

  Robotech is one of the best anime series ever made, so it is with great pleasure
that I present this theme dedicated to it. The idea for this theme came from
Gordon Typer, who was also a great help to "guide the vision"...

  Most of the sounds and pictures were found from Fox's Robotech Page at
http://www.nauticom.net/www/cheffox/Robotech/, which is a great resource for
Robotech fans all over the web. Thanks also to everyone who has a Web page
consecrated to Robotech: I browsed most of them to get some ideas...

Description: This theme is a 256 colors theme, that contains the following:
             _ A 640x480 wallpaper (256 colors)
             _ A True Type Font (Julius Black)
             _ Two animated cursors, from the Descent theme
             _ Four 16 colors icons
             _ Lots of wav's, even a supplemental one (Robotech Supplement.wav), not
               used by any event so that you can use it anywhere you want.
             _ An animated startup logo (not installed by the theme)
             _ One closing and one shutdown screen (not installed by the theme)

  This theme was made in 48 hours, so please, if there is any error in the files,
let me know so that they can be corrected. I am looking for animated cursors for
the theme, but I am not really gifted at small graphics, so if anyone can send me
some of their own conceptions, I will include them in the next version of the theme.
The animated startup logo is not very good, but it's the best I could do considering
that it was my first one ever. As for the unexistant screen saver, if anyone finds
one appropriate, let me know...

Installation: 1. Copy everything to your themes folder, except the file jlsblk.ttf,
                 which goes in your Fonts folder (e.g. c:\windows\fonts\).
              2. If you want to use the startup and shutdown screens, then backup
                 the file Logo.sys in your root directory, and the files Logow.sys
                 and Logos.sys in your windows directory (I recommend copying them
                 all to the sysbckup folder, under your windows folder).
              3. Delete these three files (c:\logo.sys, c:\windows\logow.sys and
                 c:\windows\logos.sys)
              4. Then copy the file Robotech Startup Logo.sys to your root directory,
                 and rename it Logo.sys; Copy the file Robotech Close Windows.sys to
                 your windows folder, and rename it Logow.sys; Copy the file
                 Robotech Shutdown Logo.sys to your windows folder and rename it
                 Logos.sys.
              5. You can activate the theme by choosing the Robotech theme in the
                 Desktop Themes section of the Control Panel.

Software used: Paint Shop Pro (Shareware) for graphics
               Michaelangelo for icons
               XrX animated logo utility for the animated startup logo
               Cool Edit 95 for sounds

Last words
----------

  This theme is freeware, and in no way should be considered an infringement on
copyrights. It is not endorsed by BanDai or other companies, and is, simply put,
for the enjoyment of everybody (Especially Robotech fans!!!)

  I'd like very much to receive some comments about the theme, so that it can be
improved. Please feel free to E-mail me at goriol@po-box.mcgill.ca

Hope to hear from you,
Cookie Monster
